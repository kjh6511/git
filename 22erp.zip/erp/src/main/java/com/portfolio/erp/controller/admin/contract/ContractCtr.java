package com.portfolio.erp.controller.admin.contract;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.portfolio.erp.model.contract.ContractVO;
import com.portfolio.erp.service.admin.contract.ContractSrv;

@Controller
public class ContractCtr {
	
	@Autowired
	ContractSrv cSrv;
	
	@RequestMapping("/admin/contract/contract")
	public String getContract() {	
		
		return "erp/admin/contract/contract";		
	}
	
	
	@RequestMapping("/admin/contract/contract_insert")
	@ResponseBody
	public int setContract(@ModelAttribute ContractVO cvo) {
		cvo.setContDocNum("0");
		String clientLicenseNumFk = cvo.getClientLicenseNumFk();	
		cSrv.setContract(cvo);

		int contID = cSrv.getID(clientLicenseNumFk);
		String clientCode = cSrv.getCode(clientLicenseNumFk,contID);
		String contDocNum = cvo.getTime()+ clientCode+ contID;
		cSrv.setContDocNum(contDocNum, contID);
		
		return contID;		
	}
	
	@RequestMapping(value="/admin/contract/contract_detail", method = RequestMethod.GET)
	public ModelAndView getContractDetail(
			@RequestParam int contID) {	
		ModelAndView mav = new ModelAndView();
		String contDocNum = cSrv.getcontDocNum(contID);
		
		
		mav.addObject("contID",contID);
		mav.addObject("contDocNum",contDocNum);
		mav.setViewName("erp/admin/contract/contract");		
		return mav;		
	}
	
	@RequestMapping(value="/admin/contract/contract_detail", method = RequestMethod.POST)
	@ResponseBody
	public ContractVO getContDpName(@ModelAttribute ContractVO cvo) {
		
		System.out.println(cvo.getContDpName());
		
		cvo = cSrv.getproduct(cvo.getContDpName());
		System.out.println(cvo);						
		return cvo;	
	}

	@RequestMapping("/admin/contract/contract_list")
	public ModelAndView getContractList(
			@RequestParam(defaultValue = "") String words, 
			@RequestParam(defaultValue = "cont_doc_num") String searchOpt
			) {	
		ModelAndView mav = new ModelAndView();
		List<ContractVO> list = cSrv.getcontlist(words,searchOpt);
		mav.addObject("list",list);
		mav.setViewName("erp/admin/contract/contract_list");
		return mav;		
	}
	
	@RequestMapping("/admin/contract/contract_list_delete")
	@ResponseBody
	public String setContDel(
			@RequestParam int contID) {	
		cSrv.setContDel(contID);
		return "success";		
	}
	
	
	
	
}
