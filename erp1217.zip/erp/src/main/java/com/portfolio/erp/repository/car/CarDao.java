package com.portfolio.erp.repository.car;

import java.util.List;

import com.portfolio.erp.model.employee.CarVO;

public interface CarDao {
	
	public void setCar(CarVO cvo);
	
	public void setCarUse(CarVO cvo);
	
	public List<CarVO> getCarList(String words, String searchOpt);
}
