package com.portfolio.erp.model.employee;

import java.util.Date;

public class CarVO {
	
	private int carID;
	private String carModel;
	private String carName;
	private String carNum;
	private Date carPurchaseDate;
	private String carPurchasePrice;
	private int carUseYear;
	private String carScrapValue;
	private Date carInsuranceStart;
	private Date carInsuranceEnd;
	private String carComprehensive;
	private Date carInspection;
	private String carTotalMileage;
	
	private int carPID;
	private Date carDriveDate;
	private String carDestination;
	private String carPurpose;
	private String carDriveStart;
	private String carDriveEnd;
	private String carStartKm;
	private String carEndKm;
	private String carDriver;
	private String carPassenger;
	private String carKey;
	private String carFuel;
	private String carFuelAmount;
	private String carRemark;
	
	private int carIDFk;

	public int getCarID() {
		return carID;
	}

	public void setCarID(int carID) {
		this.carID = carID;
	}

	public String getCarModel() {
		return carModel;
	}

	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getCarNum() {
		return carNum;
	}

	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}

	public Date getCarPurchaseDate() {
		return carPurchaseDate;
	}

	public void setCarPurchaseDate(Date carPurchaseDate) {
		this.carPurchaseDate = carPurchaseDate;
	}

	public String getCarPurchasePrice() {
		return carPurchasePrice;
	}

	public void setCarPurchasePrice(String carPurchasePrice) {
		this.carPurchasePrice = carPurchasePrice;
	}

	public int getCarUseYear() {
		return carUseYear;
	}

	public void setCarUseYear(int carUseYear) {
		this.carUseYear = carUseYear;
	}

	public String getCarScrapValue() {
		return carScrapValue;
	}

	public void setCarScrapValue(String carScrapValue) {
		this.carScrapValue = carScrapValue;
	}

	public Date getCarInsuranceStart() {
		return carInsuranceStart;
	}

	public void setCarInsuranceStart(Date carInsuranceStart) {
		this.carInsuranceStart = carInsuranceStart;
	}

	public Date getCarInsuranceEnd() {
		return carInsuranceEnd;
	}

	public void setCarInsuranceEnd(Date carInsuranceEnd) {
		this.carInsuranceEnd = carInsuranceEnd;
	}

	public String getCarComprehensive() {
		return carComprehensive;
	}

	public void setCarComprehensive(String carComprehensive) {
		this.carComprehensive = carComprehensive;
	}

	public Date getCarInspection() {
		return carInspection;
	}

	public void setCarInspection(Date carInspection) {
		this.carInspection = carInspection;
	}

	public String getCarTotalMileage() {
		return carTotalMileage;
	}

	public void setCarTotalMileage(String carTotalMileage) {
		this.carTotalMileage = carTotalMileage;
	}

	public int getCarPID() {
		return carPID;
	}

	public void setCarPID(int carPID) {
		this.carPID = carPID;
	}

	public Date getCarDriveDate() {
		return carDriveDate;
	}

	public void setCarDriveDate(Date carDriveDate) {
		this.carDriveDate = carDriveDate;
	}

	public String getCarDestination() {
		return carDestination;
	}

	public void setCarDestination(String carDestination) {
		this.carDestination = carDestination;
	}

	public String getCarPurpose() {
		return carPurpose;
	}

	public void setCarPurpose(String carPurpose) {
		this.carPurpose = carPurpose;
	}

	public String getCarDriveStart() {
		return carDriveStart;
	}

	public void setCarDriveStart(String carDriveStart) {
		this.carDriveStart = carDriveStart;
	}

	public String getCarDriveEnd() {
		return carDriveEnd;
	}

	public void setCarDriveEnd(String carDriveEnd) {
		this.carDriveEnd = carDriveEnd;
	}

	public String getCarStartKm() {
		return carStartKm;
	}

	public void setCarStartKm(String carStartKm) {
		this.carStartKm = carStartKm;
	}

	public String getCarEndKm() {
		return carEndKm;
	}

	public void setCarEndKm(String carEndKm) {
		this.carEndKm = carEndKm;
	}

	public String getCarDriver() {
		return carDriver;
	}

	public void setCarDriver(String carDriver) {
		this.carDriver = carDriver;
	}

	public String getCarPassenger() {
		return carPassenger;
	}

	public void setCarPassenger(String carPassenger) {
		this.carPassenger = carPassenger;
	}

	public String getCarKey() {
		return carKey;
	}

	public void setCarKey(String carKey) {
		this.carKey = carKey;
	}

	public String getCarFuel() {
		return carFuel;
	}

	public void setCarFuel(String carFuel) {
		this.carFuel = carFuel;
	}

	public String getCarFuelAmount() {
		return carFuelAmount;
	}

	public void setCarFuelAmount(String carFuelAmount) {
		this.carFuelAmount = carFuelAmount;
	}

	public String getCarRemark() {
		return carRemark;
	}

	public void setCarRemark(String carRemark) {
		this.carRemark = carRemark;
	}

	public int getCarIDFk() {
		return carIDFk;
	}

	public void setCarIDFk(int carIDFk) {
		this.carIDFk = carIDFk;
	}
	
	
}
