package com.portfolio.erp.controller.admin.car;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.portfolio.erp.model.employee.CarVO;
import com.portfolio.erp.service.car.CarSrv;

@Controller
public class CarCtr {
	@Autowired
	CarSrv carSrv;
	
	@RequestMapping(value = "/adimn/car/corp_car_log", method = RequestMethod.GET)
	public String getCarUse() {
		return"erp/admin/car/corp_car_log";
	}
	
	@RequestMapping(value = "/adimn/car/corp_car_log_insert", method = RequestMethod.POST)
	@ResponseBody
	public String setCarUse(@ModelAttribute CarVO cvo) {
		
		carSrv.setCarUse(cvo);
		return"erp/admin/car/corp_car_log";
	}
	
	@RequestMapping("/admin/car/corp_car_management")
	public ModelAndView getCar(
			@RequestParam(defaultValue = "") String words, 
			@RequestParam(defaultValue = "car_num") String searchOpt) {
		
		List<CarVO> list = carSrv.getCarList(words,searchOpt);
		ModelAndView mav = new ModelAndView();
		mav.addObject("list", list);
		mav.addObject("searchOpt", searchOpt);
		mav.addObject("words", words);
		mav.setViewName("erp/admin/car/corp_car_management");
		
		return mav;
	}
	
	@RequestMapping(value = "/admin/car/corp_car_management_insert", method = RequestMethod.POST)
	public String setCar(@ModelAttribute CarVO cvo) {
		
		System.out.println(cvo);
		
		carSrv.setCar(cvo);
		
	    
		return"erp/admin/car/corp_car_management";
	}
}
