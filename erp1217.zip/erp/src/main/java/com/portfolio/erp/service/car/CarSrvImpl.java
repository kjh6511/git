package com.portfolio.erp.service.car;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.portfolio.erp.model.employee.CarVO;
import com.portfolio.erp.repository.car.CarDao;

@Service
public class CarSrvImpl implements CarSrv{
	
	@Autowired
	CarDao cDao;

	@Override
	public void setCar(CarVO cvo) {
		cDao.setCar(cvo);
		
	}

	@Override
	public void setCarUse(CarVO cvo) {
		cDao.setCarUse(cvo);
		
	}

	@Override
	public List<CarVO> getCarList(String words, String searchOpt) {
		
		return cDao.getCarList(words, searchOpt);
	}
	
	
}
