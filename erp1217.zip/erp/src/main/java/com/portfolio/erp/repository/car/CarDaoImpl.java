package com.portfolio.erp.repository.car;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.portfolio.erp.model.employee.CarVO;

@Repository
public class CarDaoImpl implements CarDao{
	
	@Autowired
	   SqlSession sqlSession;
	
	@Override
	public void setCar(CarVO cvo) {
		sqlSession.insert("car.setCar",cvo);
		
	}

	@Override
	public void setCarUse(CarVO cvo) {
		sqlSession.insert("car.setCarUse",cvo);
		
	}

	@Override
	public List<CarVO> getCarList(String words, String searchOpt) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("words", words);
		map.put("searchOpt", searchOpt);
		
		return sqlSession.selectList("car.getCarList",map);
	}

}
