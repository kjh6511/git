package com.portfolio.erp.service.car;

import java.util.List;

import com.portfolio.erp.model.employee.CarVO;

public interface CarSrv {

	public void setCar(CarVO cvo);
	
	public void setCarUse(CarVO cvo);
	
	public List<CarVO> getCarList(String words, String searchOpt);
}
