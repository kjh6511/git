package com.portfolio.erp.controller.admin.workcenter;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.portfolio.erp.model.contract.ContractVO;
import com.portfolio.erp.model.employee.EmployeeVO;
import com.portfolio.erp.model.workcenter.WorkcenterVO;
import com.portfolio.erp.service.admin.employee.EmpSrv;
import com.portfolio.erp.service.admin.workcenter.WorkcenterSrv;

@Controller
public class WorkcenterCtr {
	
	@Autowired
	WorkcenterSrv wSrv;
	
	@Autowired
	EmpSrv empSrv;
	
	@RequestMapping("/admin/workcenter")
	public ModelAndView getworkcenter() {
		
		ModelAndView mav = new ModelAndView();
		int count = wSrv.count();
		List<WorkcenterVO> list = wSrv.getworkcenterList();
		mav.addObject("list", list);
		mav.addObject("count", count);
		mav.setViewName("erp/admin/erp_workcenter/workcenter_reg");
		return mav;	
	}
	
	@RequestMapping("/admin/workcenter_empChk")
	@ResponseBody
	public List<EmployeeVO> getempChk(@ModelAttribute EmployeeVO evo) {
		List<EmployeeVO> list = empSrv.getEmployeeList("emp_name", evo.getEmpName());
		return list;
	}
	
	@RequestMapping("/admin/workcenter_insert")
	public String setworkcenter(@ModelAttribute WorkcenterVO wvo) {
		wSrv.setworkcenter(wvo);
		return "erp/admin/erp_workcenter/workcenter_reg";
	}
}
