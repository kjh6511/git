package com.portfolio.erp.service.admin.contract;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.portfolio.erp.model.contract.ContractVO;
import com.portfolio.erp.repository.admin.contract.ContractDao;

@Service
public class ContractSrvImpl implements ContractSrv{
	 @Autowired
	 ContractDao cdao;
	
	@Override
	public void setContract(ContractVO cvo) {
		cdao.setContract(cvo);
		
	}
	
	@Override
	public void setContDocNum(String contDocNum, int contID) {
		cdao.setContDocNum(contDocNum, contID);
		
	}

	@Override
	public int getID(String clientLicenseNumFk) {
		return cdao.getID(clientLicenseNumFk);
	}

	@Override
	public String getCode(String clientLicenseNumFk, int contID) {
		return cdao.getCode(clientLicenseNumFk, contID);
	}

 
 
}
