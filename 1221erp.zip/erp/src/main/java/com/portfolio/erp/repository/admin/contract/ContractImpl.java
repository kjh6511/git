package com.portfolio.erp.repository.admin.contract;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.portfolio.erp.model.contract.ContractVO;

@Repository
public class ContractImpl implements ContractDao{
	@Autowired
	SqlSession sqlSession;

	@Override
	public void setContract(ContractVO cvo) {
		sqlSession.insert("contract.setContract",cvo);
		
	}

	@Override
	public void setContDocNum(String contDocNum, int contID) {
		Map<Object, Object> map = new HashMap<Object, Object>();
		map.put("contDocNum", contDocNum);
		map.put("contID", contID);
		sqlSession.update("contract.setContDocNum",map);
		
	}

	@Override
	public int getID(String clientLicenseNumFk) {
		return sqlSession.selectOne("contract.getID",clientLicenseNumFk);
	}

	@Override
	public String getCode(String clientLicenseNumFk, int contID) {
		Map<Object, Object> map = new HashMap<Object, Object>();
		map.put("clientLicenseNumFk", clientLicenseNumFk);
		map.put("contID", contID);
		return sqlSession.selectOne("contract.getCode",map);
	}
}
