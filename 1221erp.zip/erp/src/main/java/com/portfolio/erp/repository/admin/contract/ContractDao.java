package com.portfolio.erp.repository.admin.contract;

import com.portfolio.erp.model.contract.ContractVO;

public interface ContractDao {
	
	public void setContract(ContractVO cvo);
	
	public int getID(String clientLicenseNumFk);
	
	public String getCode(String clientLicenseNumFk, int contID);
	
	public void setContDocNum(String contDocNum, int contID);
}
