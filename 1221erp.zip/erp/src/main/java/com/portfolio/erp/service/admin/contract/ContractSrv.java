package com.portfolio.erp.service.admin.contract;

import com.portfolio.erp.model.contract.ContractVO;

public interface ContractSrv {

	public void setContract(ContractVO cvo);
	
	public int getID(String clientLicenseNumFk);
	
	public void setContDocNum(String contDocNum, int contID);
	
	public String getCode(String clientLicenseNumFk, int contID);
}
