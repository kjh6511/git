package com.portfolio.erp.controller.admin.contract;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.portfolio.erp.model.contract.ContractVO;
import com.portfolio.erp.service.admin.contract.ContractSrv;

@Controller
public class ContractCtr {
	
	@Autowired
	ContractSrv cSrv;
	
	@RequestMapping("/admin/contract/contract")
	public String getContract() {	
		
		return "erp/admin/contract/contract";		
	}
	
	
	@RequestMapping("/admin/contract/contract_insert")
	@ResponseBody
	public int setContract(@ModelAttribute ContractVO cvo) {
		cvo.setContDocNum("0");
		String clientLicenseNumFk = cvo.getClientLicenseNumFk();	
		cSrv.setContract(cvo);

		int contID = cSrv.getID(clientLicenseNumFk);
		String clientCode = cSrv.getCode(clientLicenseNumFk,contID);
		String contDocNum = cvo.getTime()+ clientCode + contID;
		cSrv.setContDocNum(contDocNum, contID);
		
		return contID;		
	}
	
	@RequestMapping("/admin/contract/contract_detail")
	public String etContract(@RequestParam int contID) {	
		System.out.println(contID);
		return "erp/admin/contract/contract";		
	}
	
	
	
}
