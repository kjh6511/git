package com.portfolio.erp.controller.regnlog;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.portfolio.erp.model.employee.EmployeeVO;
import com.portfolio.erp.service.regnlog.RegnlogSrv;

@Controller
public class RegnlogCtr {
   
   @Autowired
   RegnlogSrv regnlogSrv;
   
   @RequestMapping(value = "/login", method = RequestMethod.GET)
   public String getLogin() {
      return "regnlog/loginForm";
   }
   
   @RequestMapping(value = "/login", method = RequestMethod.POST)
   public ModelAndView getLogin(@ModelAttribute EmployeeVO evo) {
	  
	   ModelAndView mav = new ModelAndView();
	   
	   
	   int confirm = regnlogSrv.loginChk(evo);
	   String msg = "";
	   
	   if (confirm == 0) {
		   msg= "로그인 실패";
		   mav.addObject("msg",msg);
	   }else if( confirm == 1){
		  
	   }else {
		   msg ="승인을 기다립니다";
		   mav.addObject("msg", msg);
	   }
	   mav.setViewName("regnlog/registerForm");
	   return mav;
	
   }
   
//   @RequestMapping(value = "/login", method = RequestMethod.POST)
//   public String loginChk(@ModelAttribute EmployeeVO evo) {
//    int result = regnlogSrv.loginChk(evo);
//	   String msg ;
//	    if(result > 0) msg  = "success";
//	    msg = "failure";
//	    return "msg";
//   }
   
   
   
//   @RequestMapping(value = "/loginChk", method = RequestMethod.POST)
//   @ResponseBody
//   public String loginChk(
//		   @RequestParam String loginID, @RequestParam String empPassword) {
//	   System.out.println(loginID);
//	   System.out.println(empPassword);
//	   return "regnlog/loginForm";
//   }
   
   
   @RequestMapping(value = "/register", method = RequestMethod.GET)
   public ModelAndView getRegister() {
      ModelAndView mav = new ModelAndView();
      mav.addObject("departList", regnlogSrv.getDepartmentList());
      mav.addObject("positionList", regnlogSrv.getPositionList());
      mav.setViewName("regnlog/registerForm");
      return mav;
   }
   
   @RequestMapping(value = "/register", method = RequestMethod.POST)
   @ResponseBody
   public String getRegister(@ModelAttribute EmployeeVO evo) {
      
      /* 입사일 + 부서 = 사번 만들기 */
      String eYear = evo.getEmpEnter().substring(2, 4);
      String eMonth = evo.getEmpEnter().substring(5, 7);
      evo.setEmpDepartment("200");
      evo.setEmpNum(eYear + eMonth + evo.getEmpDepartment() );
      
      evo.setEmpPosition("10");
      evo.setEmpPassword(evo.getEmpBirth());
      System.out.println(evo.getEmpNum());

      /*부서 목록 불러오기*/
      
      
      regnlogSrv.setEmpOne(evo);
      return "regnlog/registerForm";
   }
   
   @RequestMapping("/register/getDepartmentList")
   @ResponseBody
   public List<EmployeeVO> getDepartmentList() {
      List<EmployeeVO> list = regnlogSrv.getDepartmentList();
      return list;
   }
   
   @RequestMapping("/register/getPositionList")
   @ResponseBody
   public List<EmployeeVO> getPositionList() {
      List<EmployeeVO> list = regnlogSrv.getPositionList();
      return list;
   }
}