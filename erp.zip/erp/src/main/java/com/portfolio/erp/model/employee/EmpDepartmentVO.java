package com.portfolio.erp.model.employee;

public class EmpDepartmentVO {
	private String departCode;
	private String departName;
	
	public String getDepartCode() {
		return departCode;
	}
	public void setDepartCode(String departCode) {
		this.departCode = departCode;
	}
	public String getDepartName() {
		return departName;
	}
	public void setDepartName(String departName) {
		this.departName = departName;
	}
	
	
}
