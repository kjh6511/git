package com.portfolio.erp.repository.regnlog;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.portfolio.erp.model.employee.EmployeeVO;

@Repository
public class RegnlogDaoImpl implements RegnlogDao{

   @Autowired
   SqlSession sqlSession;
   
   @Override
   public void setEmpOne(EmployeeVO evo) {
      sqlSession.insert("regnlog.setEmpOne", evo);
   }

   @Override
   public List<EmployeeVO> getDepartmentList() {
      List<EmployeeVO> list = sqlSession.selectList("regnlog.getDepartmentList");
      return list;
   }

   @Override
   public List<EmployeeVO> getPositionList() {
      List<EmployeeVO> list = sqlSession.selectList("regnlog.getPositionList");
      return list;
   }

	@Override
	public int loginChk(EmployeeVO evo) {
	
		int chk = 0;
		
		int logChk = sqlSession.selectOne("regnlog.loginChk",evo);
		String confirm = sqlSession.selectOne("regnlog.getLogin",evo);
		
		if(logChk == 0) {
			chk = 0;
		}else if(logChk == 1 && confirm.equals("N")){
			chk = 1;
		}else {
			chk = 2;
		}
		return chk;
	}
}
