function contDel(contID){
		if( confirm("계약내용 및 정보를 삭제하시겠습니까?") ) {
			$.ajax({
				url		: "/erp/admin/contract_list_delete",
				type	: "POST",
				data	: {contID : contID},
				success	: function(resData) {
					alert( "계약서가 삭제되었습니다.");
					window.location.reload();
					
				},
				error	:function() {
					alert("시스템 에러");			
				}
			});
		} else{
			window.location.reload();
		}
	};
	

