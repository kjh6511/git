$(function(){
    $(".topmenu ul p").click(function(){
        $(".topmenu ul li, .de").slideToggle(300);
        $(".overlay").slideToggle(300);
        
    });
});
