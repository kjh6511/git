$(function(){
    $("#tree").treeview({
        collapsed:false,
        animated:0,
        control:"#sidetreecontrol",
        persist: "location"
    });
});

