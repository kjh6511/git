package com.example.group.repository.comDao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.group.model.Grp_ComVO;



@Repository
public class ComDao {
	@Autowired
	SqlSession sql;
	
	public Grp_ComVO getCompany() {
		return sql.selectOne("company.getCompany");
	}
	
	public void setCompany(Grp_ComVO cvo) {
		sql.update("company.setCompany", cvo);
	}
}
