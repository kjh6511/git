package com.example.group.controller.grp_mypage;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/mypage")
public class Grp_mypage {
	
	@RequestMapping(value ="", method = RequestMethod.GET)
	public String getGrpMypage() {
		return"grp_mypage/grp_mypage";
	}
	
	
}
