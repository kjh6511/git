

package com.example.group.controller.lognRegCtr;

import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.group.model.Grp_ComVO;
import com.example.group.model.Grp_buseoVO;
import com.example.group.model.Grp_empVO;
import com.example.group.model.Grp_gradeVO;
import com.example.group.paging.Pager;
import com.example.group.service.comSrv.ComSrv;
import com.example.group.service.lognRegSrv.LognRegSrv;

@Controller
public class LognRegCtr {

	@Autowired
	LognRegSrv lrSrv;
	
	@Autowired
	ComSrv cSrv;
	
	@RequestMapping(value ="/grp_login", method = RequestMethod.GET)
	public ModelAndView getLogin() {
		Grp_ComVO cvo = cSrv.getCompany();
		ModelAndView mav = new ModelAndView();
		mav.addObject("comName", cvo.getComName());
		mav.addObject("comSubName", cvo.getComSubName());
		mav.setViewName("grp_login");
		return mav;
	}
	
	@RequestMapping(value = "/grp_login", method = RequestMethod.POST)
	public ModelAndView setgrpLogin(@ModelAttribute Grp_empVO evo, HttpSession session) {
		int result = lrSrv.EmpNumCheck(evo);
		Grp_ComVO cvo = cSrv.getCompany();
		int auth = cSrv.getCompany().getComAuth();

		ModelAndView mav = new ModelAndView();
		String msg;
		if (result > 0) {
			Grp_empVO vo = lrSrv.loginCheck(evo);
			if (vo.getEmpAuth() >= auth && vo.getEmpConfirm().equals("Y")) {
				lrSrv.setSession(evo, session);
				mav.setViewName("redirect:/grp_main/grp_main");
			} else {
				msg = "접속권한이 없습니다.\n관리자에게 문의하세요.";
				mav.addObject("msg", msg);
				mav.setViewName("grp_login");
			}
		} else {
			msg = "등록된 사번이 아닙니다.";
			mav.addObject("msg", msg);
			mav.setViewName("grp_login");
		}
		return mav;
	}
	
	@RequestMapping(value = "/idCheck", method = RequestMethod.POST)
	@ResponseBody
	public String idCheck(@RequestParam String empNum) {
		int result =lrSrv.idCheck(empNum);
	
		String msg = null;
		
		if(result > 0) msg ="No";
		else msg="Ok";
		
		
		return msg; //뒤로가기 문제 해결
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	@ResponseBody
	public String logout(HttpSession session) {
		lrSrv.logout(session);
		return "Ok";
		
	}
	
	@RequestMapping(value = "/grp_get_buseo", method =RequestMethod.POST)
	@ResponseBody
	public List<Grp_buseoVO> grpGetBuseo() {
		List<Grp_buseoVO> list = lrSrv.grpGetBuseo();
		return list;
	}
	
	@RequestMapping(value = "/grp_get_grade", method =RequestMethod.POST)
	@ResponseBody
	public List<Grp_gradeVO> grpGetGrade() {
		List<Grp_gradeVO> list = lrSrv.grpGetGrade();
		return list;
	}
	
	@RequestMapping(value ="/grp_register", method = RequestMethod.GET)
	public String getRegister() {
		return "/grp_register";
	}
	
	@RequestMapping(value = "/grp_register", method = RequestMethod.POST)
	public String setRegister(@ModelAttribute Grp_empVO evo) {
		/*사원번호 만들기 입사년+부서코드+직급코드+pk*/
		int enterYear = Integer.parseInt(evo.getEmpEnter().substring(0,4));//2020
		String bCode = evo.getEmpBuseoCode();
		String gCode = evo.getEmpGradeCode();
		
		String eNum = enterYear + bCode + gCode;
		evo.setEmpNum(eNum);
		/*사원번호 만들기*/
		
		/*호봉 : empStep = 현재년도 - 입사년도 */
		Calendar cal = Calendar.getInstance();
		int hYear = cal.get(Calendar.YEAR);
		int eStep = (hYear-enterYear) + 1;
		evo.setEmpStep(eStep);
		/*호봉 : empStep = 현재년도 - 입사년도 */
		lrSrv.setRegisterOne(evo);		
		return "redirect:/grp_login";
	}
	
	@RequestMapping("/registerList/registerList")
	public ModelAndView getregisterList(
			@RequestParam(defaultValue = "1") int curPage,
			@RequestParam(defaultValue = "emp_name") String searchOpt,
			@RequestParam(defaultValue = "") String words) {
		
		int count = lrSrv.getCount(searchOpt, words);
		Pager pager = new Pager(count, curPage);
		int start = pager.getPageBegin();
		int end = pager.getPageEnd();
        List<Grp_empVO> list = lrSrv.getRegisterAll(start, end,searchOpt, words);
		
		ModelAndView mav =new ModelAndView();
		mav.addObject("searchOpt", searchOpt);
		mav.addObject("words", words);
		mav.addObject("count", count);
		mav.addObject("list", list);
		mav.addObject("start", start); //게시물 개수 자를 시작번호
		mav.addObject("end", end); //게시물 자를 끝번호
		mav.addObject("blockBegin", pager.getBlockBegin());
		mav.addObject("blockEnd", pager.getBlockEnd());
		mav.addObject("curBlock", pager.getCurBlock());
		mav.addObject("totalBlock", pager.getTotBlock());
		mav.addObject("prevPage", pager.getPrevPage());
		mav.addObject("nextPage", pager.getNextPage());
		mav.addObject("curPage", pager.getCurPage());
		mav.addObject("totalPage", pager.getTotPage());
		//페이지 번호를 클릭했을 때 css active 클래스 처리
		mav.addObject("selected", pager.getCurPage());
		mav.setViewName("registerList/registerList");
		
		return mav;
	}
	
	@RequestMapping("/levelChange")
	@ResponseBody
	public String levelChange(@ModelAttribute Grp_empVO evo){
		lrSrv.levelChange(evo);
		return "Ok";
	}
	@RequestMapping("/regConfirm")
	@ResponseBody
	public String regConfirm(@ModelAttribute Grp_empVO evo){
		lrSrv.regConfirm(evo);
		return "Ok";
		
	}
	@RequestMapping("/delete")
	@ResponseBody
	public String setRegisterDeleteOne(@RequestParam int mid) {
		lrSrv.setRegisterDeleteOne(mid);
		return "Ok";
	}
	
	@RequestMapping("/grp_main/grp_main")
	public String getGrp_Main() {
		return "grp_main/grp_main";
	}
	
	@RequestMapping(value = "/registerList/registerUpdate", method = RequestMethod.GET)
	public ModelAndView getRegisterUpdate(@RequestParam int empID) {
		ModelAndView mav = new ModelAndView();
		Grp_empVO evo = lrSrv.getRegisterUpdateOne(empID);
		
		mav.addObject("update", evo);
		mav.setViewName("registerList/registerUpdate");
		
		return mav;
	}
	
	@RequestMapping(value = "/registerList/registerUpdate", method = RequestMethod.POST)
	public String setRegisterUpdate(@ModelAttribute Grp_empVO evo) {
		lrSrv.setRegisterUpdateOne(evo);
		
		return "redirect:/registerList/registerList";
	}
	
	
}
