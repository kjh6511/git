package com.example.group.service.comSrv;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.group.model.Grp_ComVO;
import com.example.group.repository.comDao.ComDao;


@Service
public class ComSrv {
	@Autowired
	ComDao cDao;
	
	public Grp_ComVO getCompany() {
		return cDao.getCompany();
	}
	
	public void setCompany(Grp_ComVO cvo) {
		cDao.setCompany(cvo);
	}
}
