package com.example.group.service.smpSrv;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.group.model.Grp_empVO;
import com.example.group.repository.empDao.EmpDao;

@Service
public class EmpSrv {
	
	@Autowired
	EmpDao eDao;
	
	public List<Grp_empVO> getEmpList(int start, int end, String searchOpt, String words) {
		return eDao.getEmpList(start, end,searchOpt, words);
	}
	
	public int getEmpCount(String searchOpt, String words) {
		return eDao.getEmpCount(searchOpt, words);
	}
	
	public void setEmpDelete(int eid) {
		eDao.setEmpDelete(eid);
	}
	
	public void setEmpHeadChange(String empHead, int empID) {
		eDao.setEmpHeadChange(empHead, empID);
	}
	
	public void setEmpConfirmChange(String empConfirm, int empID) {
		eDao.setEmpConfirmChange(empConfirm, empID);
	}
	
	public void setEmpAuthChange(String empAuth, int empID) {
		eDao.setEmpAuthChange(empAuth, empID);
	}
}
