package com.example.group.model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Grp_empVO {
	
	private int empID;
	private String empBuseoCode ;
	private String empBuseoName ;
	private String empGradeCode ;
	private String empGradeName ;
	private String empNum ;
	private String empEnter;
	private String empName ;
	private String empPwd ;
	private String empPhone;
	private String empEmail;	
	private String empPhoto ;
	private Date empRegdate ;
	private String empHead ;
	private int empStep ;
	private int empAuth ;
	private String empConfirm ;
	private int ref;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	private int empOid;
	private String empGender;
	private String empBirth;
	private String empCp;
	private String empIn;
	private String empTel;
	private String empRecruit;
	private String empHope;
	private String empHeight;
	private String empWeight;
	private String empReligion;
	private String empHobby;
	private String empSpeciality;
	private String empDisability;
	private String empReward;
	private String empMarride;
	private String empLicense1;
	private String empLicense2;
	private String empLicense3;
	private String empLicense4;
	private String empLicense5;
	private String empLeng1;
	private String empLeng2;
	private String empLeng3;
	private String empLeng4;
	private String empLeng5;
	private String empRnp1;
	private String empRnp2;
	private String empRnp3;
	private String empRnp4;
	private String empRnp5;
	private String Comment;
	private int empIDRK;
	
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getEmpBuseoCode() {
		return empBuseoCode;
	}
	public void setEmpBuseoCode(String empBuseoCode) {
		this.empBuseoCode = empBuseoCode;
	}
	public String getEmpBuseoName() {
		return empBuseoName;
	}
	public void setEmpBuseoName(String empBuseoName) {
		this.empBuseoName = empBuseoName;
	}
	public String getEmpGradeCode() {
		return empGradeCode;
	}
	public void setEmpGradeCode(String empGradeCode) {
		this.empGradeCode = empGradeCode;
	}
	public String getEmpGradeName() {
		return empGradeName;
	}
	public void setEmpGradeName(String empGradeName) {
		this.empGradeName = empGradeName;
	}
	public String getEmpNum() {
		return empNum;
	}
	public void setEmpNum(String empNum) {
		this.empNum = empNum;
	}
	public String getEmpEnter() {
		return empEnter;
	}
	public void setEmpEnter(String empEnter) {
		this.empEnter = empEnter;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpPwd() {
		return empPwd;
	}
	public void setEmpPwd(String empPwd) {
		this.empPwd = empPwd;
	}
	public String getEmpPhone() {
		return empPhone;
	}
	public void setEmpPhone(String empPhone) {
		this.empPhone = empPhone;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpPhoto() {
		return empPhoto;
	}
	public void setEmpPhoto(String empPhoto) {
		this.empPhoto = empPhoto;
	}
	public String getEmpRegdate() {
		return sdf.format(empRegdate);
	}
	public void setEmpRegdate(Date empRegdate) {
		this.empRegdate = empRegdate;
	}
	public String getEmpHead() {
		return empHead;
	}
	public void setEmpHead(String empHead) {
		this.empHead = empHead;
	}
	public int getEmpStep() {
		return empStep;
	}
	public void setEmpStep(int empStep) {
		this.empStep = empStep;
	}
	public int getEmpAuth() {
		return empAuth;
	}
	public void setEmpAuth(int empAuth) {
		this.empAuth = empAuth;
	}
	public String getEmpConfirm() {
		return empConfirm;
	}
	public void setEmpConfirm(String empConfirm) {
		this.empConfirm = empConfirm;
	}
	public int getRef() {
		return ref;
	}
	public void setRef(int ref) {
		this.ref = ref;
	}
	public int getEmpOid() {
		return empOid;
	}
	public void setEmpOid(int empOid) {
		this.empOid = empOid;
	}
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	public String getEmpBirth() {
		return empBirth;
	}
	public void setEmpBirth(String empBirth) {
		this.empBirth = empBirth;
	}
	public String getEmpCp() {
		return empCp;
	}
	public void setEmpCp(String empCp) {
		this.empCp = empCp;
	}
	public String getEmpIn() {
		return empIn;
	}
	public void setEmpIn(String empIn) {
		this.empIn = empIn;
	}
	public String getEmpTel() {
		return empTel;
	}
	public void setEmpTel(String empTel) {
		this.empTel = empTel;
	}
	public String getEmpRecruit() {
		return empRecruit;
	}
	public void setEmpRecruit(String empRecruit) {
		this.empRecruit = empRecruit;
	}
	public String getEmpHope() {
		return empHope;
	}
	public void setEmpHope(String empHope) {
		this.empHope = empHope;
	}
	public String getEmpHeight() {
		return empHeight;
	}
	public void setEmpHeight(String empHeight) {
		this.empHeight = empHeight;
	}
	public String getEmpWeight() {
		return empWeight;
	}
	public void setEmpWeight(String empWeight) {
		this.empWeight = empWeight;
	}
	public String getEmpReligion() {
		return empReligion;
	}
	public void setEmpReligion(String empReligion) {
		this.empReligion = empReligion;
	}
	public String getEmpHobby() {
		return empHobby;
	}
	public void setEmpHobby(String empHobby) {
		this.empHobby = empHobby;
	}
	public String getEmpSpeciality() {
		return empSpeciality;
	}
	public void setEmpSpeciality(String empSpeciality) {
		this.empSpeciality = empSpeciality;
	}
	public String getEmpDisability() {
		return empDisability;
	}
	public void setEmpDisability(String empDisability) {
		this.empDisability = empDisability;
	}
	public String getEmpReward() {
		return empReward;
	}
	public void setEmpReward(String empReward) {
		this.empReward = empReward;
	}
	public String getEmpMarride() {
		return empMarride;
	}
	public void setEmpMarride(String empMarride) {
		this.empMarride = empMarride;
	}
	public String getEmpLicense1() {
		return empLicense1;
	}
	public void setEmpLicense1(String empLicense1) {
		this.empLicense1 = empLicense1;
	}
	public String getEmpLicense2() {
		return empLicense2;
	}
	public void setEmpLicense2(String empLicense2) {
		this.empLicense2 = empLicense2;
	}
	public String getEmpLicense3() {
		return empLicense3;
	}
	public void setEmpLicense3(String empLicense3) {
		this.empLicense3 = empLicense3;
	}
	public String getEmpLicense4() {
		return empLicense4;
	}
	public void setEmpLicense4(String empLicense4) {
		this.empLicense4 = empLicense4;
	}
	public String getEmpLicense5() {
		return empLicense5;
	}
	public void setEmpLicense5(String empLicense5) {
		this.empLicense5 = empLicense5;
	}
	public String getEmpLeng1() {
		return empLeng1;
	}
	public void setEmpLeng1(String empLeng1) {
		this.empLeng1 = empLeng1;
	}
	public String getEmpLeng2() {
		return empLeng2;
	}
	public void setEmpLeng2(String empLeng2) {
		this.empLeng2 = empLeng2;
	}
	public String getEmpLeng3() {
		return empLeng3;
	}
	public void setEmpLeng3(String empLeng3) {
		this.empLeng3 = empLeng3;
	}
	public String getEmpLeng4() {
		return empLeng4;
	}
	public void setEmpLeng4(String empLeng4) {
		this.empLeng4 = empLeng4;
	}
	public String getEmpLeng5() {
		return empLeng5;
	}
	public void setEmpLeng5(String empLeng5) {
		this.empLeng5 = empLeng5;
	}
	public String getEmpRnp1() {
		return empRnp1;
	}
	public void setEmpRnp1(String empRnp1) {
		this.empRnp1 = empRnp1;
	}
	public String getEmpRnp2() {
		return empRnp2;
	}
	public void setEmpRnp2(String empRnp2) {
		this.empRnp2 = empRnp2;
	}
	public String getEmpRnp3() {
		return empRnp3;
	}
	public void setEmpRnp3(String empRnp3) {
		this.empRnp3 = empRnp3;
	}
	public String getEmpRnp4() {
		return empRnp4;
	}
	public void setEmpRnp4(String empRnp4) {
		this.empRnp4 = empRnp4;
	}
	public String getEmpRnp5() {
		return empRnp5;
	}
	public void setEmpRnp5(String empRnp5) {
		this.empRnp5 = empRnp5;
	}
	public String getComment() {
		return Comment;
	}
	public void setComment(String comment) {
		Comment = comment;
	}
	public int getEmpIDRK() {
		return empIDRK;
	}
	public void setEmpIDRK(int empIDRK) {
		this.empIDRK = empIDRK;
	} 
	
	
	
}
