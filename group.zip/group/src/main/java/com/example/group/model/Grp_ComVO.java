package com.example.group.model;

public class Grp_ComVO {
	private String comName;
	private String comSubName;
	private String comCeo;
	private String comTel;
	private String comUrl;
	private String comCopy;
	private int comAuth;
	private String comMainLogo;
	private String comMenu;
	private String comMainUp;
	private String comMainDown;
	
	public String getComName() {
		return comName;
	}
	public void setComName(String comName) {
		this.comName = comName;
	}
	public String getComSubName() {
		return comSubName;
	}
	public void setComSubName(String comSubName) {
		this.comSubName = comSubName;
	}
	public String getComCeo() {
		return comCeo;
	}
	public void setComCeo(String comCeo) {
		this.comCeo = comCeo;
	}
	public String getComTel() {
		return comTel;
	}
	public void setComTel(String comTel) {
		this.comTel = comTel;
	}
	public String getComUrl() {
		return comUrl;
	}
	public void setComUrl(String comUrl) {
		this.comUrl = comUrl;
	}
	public String getComCopy() {
		return comCopy;
	}
	public void setComCopy(String comCopy) {
		this.comCopy = comCopy;
	}
	public int getComAuth() {
		return comAuth;
	}
	public void setComAuth(int comAuth) {
		this.comAuth = comAuth;
	}
	public String getComMainLogo() {
		return comMainLogo;
	}
	public void setComMainLogo(String comMainLogo) {
		this.comMainLogo = comMainLogo;
	}
	public String getComMenu() {
		return comMenu;
	}
	public void setComMenu(String comMenu) {
		this.comMenu = comMenu;
	}
	public String getComMainUp() {
		return comMainUp;
	}
	public void setComMainUp(String comMainUp) {
		this.comMainUp = comMainUp;
	}
	public String getComMainDown() {
		return comMainDown;
	}
	public void setComMainDown(String comMainDown) {
		this.comMainDown = comMainDown;
	}
}
