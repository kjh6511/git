package com.example.group.service.boardSrv;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.group.model.Grp_boardVO;
import com.example.group.repository.boardDao.BoardDao;



@Service
public class BoardSrv {
	
	@Autowired
	BoardDao boardDao;
	
	public void setBoard(Grp_boardVO bvo) {
		boardDao.setBoard(bvo);
	}
	
	public void createArticleTbl(String boardCode) {
		boardDao.createArticleTbl(boardCode);
	}
	
	public void createCommentTbl(String boardCode) {
		boardDao.createCommentTbl(boardCode);
	}
	
	public int getboardChk(String boardCode) {
		return boardDao.getboardChk(boardCode);
	}
	
	public List<Grp_boardVO> getBoardList(int start, int end) {
		return boardDao.getBoardList(start,end);
	}
	public void setBoardDelete(String boardCode) {
		boardDao.setBoardDelete(boardCode);
	}
	
	public void dropArticleTbl(String boardCode) {
		boardDao.dropArticleTbl(boardCode);
	}
	
	public void dropCommentTbl(String boardCode) {
		boardDao.dropCommentTbl(boardCode);
	}
	
	public int getBoardCount() {
		return boardDao.getBoardCount();
	}
}
