package com.example.group.repository.empDao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.group.model.Grp_empVO;



@Repository
public class EmpDao {

	@Autowired
	SqlSession sql;
	
	public List<Grp_empVO> getEmpList(int start, int end, String searchOpt, String words) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("searchOpt", searchOpt);
		map.put("words", words);
		map.put("start", start);
		map.put("end", end);
		return sql.selectList("employee.getEmpList", map);
	}
	
	public int getEmpCount(String searchOpt, String words) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("searchOpt", searchOpt);
		map.put("words", words);
		return sql.selectOne("employee.getEmpCount", map);
	}
	
	public void setEmpDelete(int eid) {
		sql.delete("employee.setEmpDelete", eid);
	}
	
	public void setEmpHeadChange(String empHead, int empID) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("empHead", empHead);
		map.put("empID", empID);
		sql.update("employee.setEmpHeadChange", map);
	}
	
	public void setEmpConfirmChange(String empConfirm, int empID) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("empConfirm", empConfirm);
		map.put("empID", empID);
		sql.update("employee.setEmpConfirmChange", map);
	}
	public void setEmpAuthChange(String empAuth, int empID) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("empAuth", empAuth);
		map.put("empID", empID);
		sql.update("employee.setEmpAuthChange", map);
	}
}
