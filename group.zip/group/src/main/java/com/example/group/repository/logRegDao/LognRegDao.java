package com.example.group.repository.logRegDao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.group.model.Grp_buseoVO;
import com.example.group.model.Grp_empVO;
import com.example.group.model.Grp_gradeVO;

@Repository
public class LognRegDao {
	
	@Autowired
	SqlSession sql;
	
	public List<Grp_buseoVO> grpGetBuseo(){
		return sql.selectList("register.grpGetBuseo");
	}
	public List<Grp_gradeVO> grpGetGrade(){
		return sql.selectList("register.grpGetGrade");
	}	
	public void setRegisterOne(Grp_empVO evo) {
		sql.insert("register.setRegisterOne",evo);	
	}
	public int idCheck(String empNum) {
		return sql.selectOne("register.idCheck",empNum);
	}
	public int EmpNumCheck(Grp_empVO evo) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("empNum",evo.getEmpNum());
		map.put("empPwd",evo.getEmpPwd());
		return sql.selectOne("register.idCheck", map);
	}	
	public Grp_empVO loginCheck(Grp_empVO evo) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("empNum",evo.getEmpNum());
		map.put("empPwd",evo.getEmpPwd());
		return sql.selectOne("register.loginCheck", map);
	}
	public List<Grp_empVO> getRegisterAll(int start, int end, String searchOpt, String words) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("searchOpt", searchOpt);
		map.put("words", words);
		map.put("start", start);
		map.put("end", end);
		return sql.selectList("register.getRegisterAll",map);
	}
	public int getCount(String searchOpt, String words) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("searchOpt", searchOpt);
		map.put("words", words);
		return sql.selectOne("register.getCount",map);
	}
	public void regConfirm(Grp_empVO evo) {
		sql.update("register.setRegConfirm", evo);
	}
	public void levelChange(Grp_empVO evo) {
		sql.update("register.levelChange",evo);
		
	}
	public void setRegisterDeleteOne(int empID) {
		sql.delete("register.setRegisterDeleteOne", empID);
	}
	public void setRegisterUpdateOne(Grp_empVO evo) {
		sql.update("register.setRegisterUpdateOne", evo);
	}
	public Grp_empVO getRegisterUpdateOne(int empID) {
		return sql.selectOne("register.getRegisterUpdateOne", empID);
	}
}
