package com.example.group.service.lognRegSrv;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.group.model.Grp_buseoVO;
import com.example.group.model.Grp_empVO;
import com.example.group.model.Grp_gradeVO;
import com.example.group.repository.logRegDao.LognRegDao;

@Service
public class LognRegSrv {
	
	@Autowired
	LognRegDao lrDao;
	
	public List<Grp_buseoVO> grpGetBuseo(){
		return lrDao.grpGetBuseo();
	}
	
	public List<Grp_gradeVO> grpGetGrade(){
		return lrDao.grpGetGrade();
	}
	
	public void setRegisterOne(Grp_empVO evo) {
		lrDao.setRegisterOne(evo);
	}
	public int idCheck(String empNum) {
		return lrDao.idCheck(empNum);
	}
	
	public int EmpNumCheck(Grp_empVO evo) {
		return lrDao.EmpNumCheck(evo);
	}
	public Grp_empVO loginCheck(Grp_empVO evo) {
		return lrDao.loginCheck(evo);
	}
	
	public void setSession(Grp_empVO evo, HttpSession session) {
		Grp_empVO vo= lrDao.loginCheck(evo);	
		if( vo != null) {
		session.setAttribute("empNum", vo.getEmpNum());
		session.setAttribute("empName", vo.getEmpName());
		session.setAttribute("empAuth", vo.getEmpAuth());
		session.setAttribute("empConfirm", vo.getEmpConfirm());
		session.setAttribute("empBuseoName", vo.getEmpBuseoName());
		session.setAttribute("empGradeName", vo.getEmpGradeName());
		}
	}
	public void logout(HttpSession session) {
		session.invalidate();
	}
	public List<Grp_empVO> getRegisterAll(int start, int end, String searchOpt, String words) {
		return lrDao.getRegisterAll(start, end, searchOpt, words);
	}
	public int getCount(String searchOpt, String words) {
		return lrDao.getCount(searchOpt, words);
	}
	public void regConfirm(Grp_empVO evo) {
		lrDao.regConfirm(evo);
	}
	public void levelChange(Grp_empVO evo) {
		lrDao.levelChange(evo);
	}
	public void setRegisterDeleteOne(int empID) {
		lrDao.setRegisterDeleteOne(empID);
	}
	public void setRegisterUpdateOne(Grp_empVO evo) {
		lrDao.setRegisterUpdateOne(evo);
	}
	public Grp_empVO getRegisterUpdateOne(int empID) {
		return lrDao.getRegisterUpdateOne(empID);
	}
}
