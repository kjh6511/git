package com.example.group.controller.grp_messageCtr;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/message")
public class Grp_messageCtr {
	
	@RequestMapping(value ="", method = RequestMethod.GET)
	public String getMessage(){
		return "grp_message/grp_message";
	}
	
	@RequestMapping(value ="/grp_message_write", method = RequestMethod.GET)
	public String getMessageWrite(){
		return "grp_message/grp_message_write";
	}
	
	@RequestMapping(value ="/grp_message_view", method = RequestMethod.GET)
	public String getMessageView(){
		return "grp_message/grp_message_view";
	}
	
}
