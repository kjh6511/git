package com.example.group.controller.comCtr;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.group.model.Grp_ComVO;
import com.example.group.service.comSrv.ComSrv;


@Controller
@RequestMapping("/company")
public class ComCtr {
	
	@Autowired
	ComSrv cSrv;

	@RequestMapping(value = "", method = RequestMethod.GET)
	public String getCompany() {
		return "grp_company/grp_company_main";
	}
	
	@RequestMapping(value = "", method = RequestMethod.POST)
	@ResponseBody
	public Grp_ComVO getCompanyInfo() {
		Grp_ComVO cvo = cSrv.getCompany();
		return cvo;
	}
	
	@RequestMapping(value = "/grp_company", method = RequestMethod.POST)
	public String grpCompany(@ModelAttribute Grp_ComVO cvo) {
		cSrv.setCompany(cvo);
		return "grp_company/grp_company_main";
	}
}
